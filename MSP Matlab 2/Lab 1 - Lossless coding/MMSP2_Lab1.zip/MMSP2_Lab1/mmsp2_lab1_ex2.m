%% MMSP2 - Lab 1
%  Exercise 2 - Image signal encoding

clearvars
close all
clc

%% 1) Load the image 'lena512color.tiff' and display the normalized histogram 
%%    for all (R,G,B) components
%%    hint: 'lena512color.tiff' is an 8-bit RGB image, better to convert into double
%%    hint: express the RGB components as vectors





%% 2) Compute the entropy of each channel





%% 3) Let X represent the source of the red channel and Y the source of the
%%    green channel. Compute and show p(X,Y).
%%    hint: use the function imagesc() to show p(X,Y)





%% 4) Compute and display the joint entropy H(X,Y) and verify that H(X,Y) ≤ H(X) + H(Y).





%% 5) Suppose to encode Y with H(Y) bits and transmit source N = aX+b-Y instead of X
%%    Compute the entropy of N and the conditional entropy H(X|Y)
% Compute coefficients a and b with LS




% Compute H(N)



% Conditional entropy H(X|Y) = H(X,Y) - H(Y)
















