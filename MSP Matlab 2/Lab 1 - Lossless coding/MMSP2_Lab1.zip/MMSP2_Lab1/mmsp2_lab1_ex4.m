%% MMSP2 - Lab 1
%  Exercise 4 - Discrete memoryless source coding
%  From 19 June 2006 exam

clearvars
close all
clc

%% Generate N=10000 samples of an AR(1) random process
%% y(n) = rho*y(n-1)+w(n), rho=0.99, w(n) is gaussian with variance=1



%% Clip sample values in the range [-20,20] and round to nearest integer



%% Compute H(Y) assuming that Y is a discrete memoryless source

