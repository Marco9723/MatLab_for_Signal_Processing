%% MMSP2 - Lab 1
%  Exercise 3 - Discrete memoryless source coding

clearvars
close all
clc

%% 1) Generate one realization of length 1000000 of the following process:
%%    y(n)=min(max(0,round(rho*y(n-1)+w(n))),15)
%%    where rho=0.95 and w(n) is Gaussian with variance=1



% for loop generation




% [-20, 20]





%% 2) Determine the size of the alphabet of the source
%%    hint: use the function unique()


%% 3) Find H(Y) assuming that y is a discrete memoryless source



%% 4) Let J=y(n) and K=rho*y(n-1). Compute p(J,K) and H(J,K)



%% compute joint entropy



%% 5) Compute the conditional entropy H(J|K)


% compute conditional entropy using chain rule









