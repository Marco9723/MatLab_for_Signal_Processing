%% MMSP2 - Lab 3
%  Exercise 1 - Predictive coding

clear
close all
clc


%% 1) Generate 10000 samples of the random process
%%    x(n) = rho*x(n-1) + z(n), where rho=0.95 and z(n)~N(0,0.1)


%% 2) Build a PCM codec. Quantize the signal with a uniform quantizer and
%%    R bits. Compute the R-D curve for R=1,2,...,8 bits (in terms of SNR)


%% 3) Build a predictive codec in open loop. Use the optimal MMSE predictor.
%%    Use PCM to initialize the codec


    % first sample: PCM

    
    % next samples: OLPC

    % MSE

    

% SNR


%% 4) Build a DPCM codec. Use the optimal MMSE predictor.
%%    Use PCM to initialize the codec.

    
    % first sample: PCM
    
    
    % next samples: DPCM
    
    
    % MSE


% SNR



%% 5) Compare R-D curves for PCM, open-loop DPCM and closed-loop DPCM



















