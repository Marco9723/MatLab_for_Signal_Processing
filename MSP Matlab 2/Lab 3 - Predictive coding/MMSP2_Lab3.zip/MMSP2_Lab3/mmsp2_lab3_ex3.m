clearvars
close all
clc

%% Load the audio file


%% Quantize it using PCM with 1:8 bit, using floor, ceil and round in the quantizer.
%% Compute the SNR.


    
    % Determine delta
    
    
    % Quantize x
    
    
    % Compute MSE_pcm
   

%% Plot the SNR for the different method. Is there something strange?











