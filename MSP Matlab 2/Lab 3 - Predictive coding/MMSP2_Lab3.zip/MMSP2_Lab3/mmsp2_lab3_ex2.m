%% MMSP2 - Lab 3
%  Exercise 2 - Predictive coding

clear
close all
clc

%% Load the stereo file ‘mso.wav’ and define xl and xr as
%% the left and right channels, respectively.




%% 1) Build a DPCM codec. Use the left channel xl as a signal and
%%      1.1) xl(n-1)
%%      1.2) xr(n)
%%      1.3) dummy 5*xl(n)
%% as predictor.
%%    Use PCM to initialize the codec.



    % first sample: PCM
   
    
    % next samples: DPCM
    
    
        % predict xl(n) from xl(n-1)
        
        
        % predict xl(n) from xr(n)
        
        
        % predict xl(n) from dummy linear combination
        

    % PCM
   
    % MSE
    
% SNR



%% 2) Compare R-D curves 













