clearvars
close all
clc

%% 1) Load the image 'lena512color.tiff'



%% 2) Let x be the red channel and y the green channel of the image.
%% Quantize y with PCM and DPCM (R=1,2,...,8 bits) using:
%%      2.1) y_hat(n) = a*x(n)+b
%%      2.2) y_hat(n) = randn*x(n) + randn*100



% Compute coefficients a and b with LS


% DPCM predictor


% Dummy DPCM predictor

    
    % DPCM
      
    % PCM
    
    % Dummy DPCM
        
    % MSE
    
% SNR

%% Compare the R-D curves











