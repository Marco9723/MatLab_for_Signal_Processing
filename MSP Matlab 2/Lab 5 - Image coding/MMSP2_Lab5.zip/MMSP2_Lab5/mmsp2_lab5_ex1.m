%% MMSP2 - Lab 5
%  Exercise 1 - DCT/KLT comparison
 
clear 
close all
clc


%% 1) Load the image 'mandrill512color.tiff' and extract the luminance component



%% 2) Consider the first 8x8 pixels block and compute its 8x8 DCT coefficients.
% Use different methods and compare them.

% dimension of the image block

% dimension of the projection space


% Method 1: use the separability property of DCT
% Define transform matrix using the given equation
% Apply transform matrix by rows and by columns



% Method 2: as method 1 but using the function dctmtx() to build the transform matrix 


% Method 3: use function dct2()


% Method 4: define the transformation g(n1,n2,k1,k2) and apply it


% Compute the MSE between coefficients in the different cases



% Are really all these methods equal?



%% 3) JPEG baseline coding - estimate the PSNR and display the reconstructed image


% quantization matrix

% scaling factor (fine --> coarse)


% store the quantized symbols to compute entropy later on


% loop over each 8x8 pixels block (no overlap)

        
        % 3a) consider block of size 8x8
        
        
        % 3b) compute the DCT (function dct2())
        
        
        % 3c) threshold quantization

        
        % 3d) reconstruct the image from quantized coefficients (function idct2())

        
% display image and compute PSNR and entropy


%% 4a) Reconstruct the image using only the DC component of the DCT - estimate the PSNR and display the reconstructed image
% store the quantized symbols to compute entropy later on


        
        % 4a) consider block of size 8x8
        
        % 4b) compute the DCT
        
        
        % 4c) keep only DC
        
        
        % 4d) reconstruct the image from quantized coefficients
        

% display image and compute PSNR

% any comment?


%% 4b) Reconstruct the image using only one AC component of the DCT
% Do not quantize, just for the sake of reconstruction


% fix one component

        
        %% 4a) consider block of size 8x8
        
        
        %% 4b) compute the DCT
        
        %% 4c) keep only coeff (k1, k2)
        
        %% 4d) reconstruct the image from quantized coefficients


%% 5) Consider blocks of dimension 8x8 and estimate the correlation matrix

% compute image blocks

% compute and remove the mean block


%% 6) Perform KLT coding - estimate the PSNR and display the reconstructed image
% Compute transform matrix from correlation



% For each block

        % 6a) consider block of size 8x8
        
        
        % 6b) compute the KLT
        

        % 6c) threshold quantization
        
        
        % 6d) reconstruct the image from quantized coefficients (use reshape() if needed)
        

% display image and compute PSNR  and entropy












