%% MMSP2 - Lab 6
%  Exercise 2 - ME and MC

clear
close all
clc

%% 1) Load the sequence 'table_tennis.mat' and spatially resize it at half the resolution (hint: use imresize())



%% 2) Compute the displaced frame difference - use 8x8 blocks, full-search, W=16, save all motion vectors and visualize them (use quiver())


% loop over each block

        %select a block
        
                    
        
        %minimum

        
        % build the cost function
   
        %save motion vectors
        
       
        
        % store the predicted frame
        


%% Compute DFD

%% 3) Compute mean and variance of DFD and normal frame difference



%% 4) Display DFD and frame difference 
