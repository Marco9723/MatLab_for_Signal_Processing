%% MMSP2 - Lab 6
%  Exercise 1 - ME and MC

clear
close all
clc

%% 1) Load the sequence 'table_tennis.mat' consisting of two grayscale frames

load table_tennis.mat

%% 2) Select the 8x8 block starting at (x,y)=(35,150) of the second frame.
% Perform ME using W=16 pixels and the first frame as reference

% select the 8x8 blocks


%find the position of the minimum



%% 3) Display the cost function, the starting block and its estimate






