clear
close all
clc


%% 1) Load the file 'voiced_a.wav' and consider only a 300ms frame.
% Plot the magnitude of the frequency response of the frame




%% 2) Perform pitch detection using auto-correlation method.
%  Consider only frequencies between 60 Hz and 500 Hz


% compute autocorrelation (hint: use two output arguments of xcorr() and 
% pay attention to MATLAB normalization)

% consider correlation only for positive lags, including 0


% find maximum peak within the accepted range, pay attention to the
% indexing



%the signal into the desired range


% value and index of the maximum

% back to the original signal


%% 3) Compute LPC coefficients of order 12
% hint: if using correlation, consider only positive lag values.
% Use toeplitz() to build correlation matrix from correlation vector


% Alternatively, you can use the lpc() function, be aware of what is returned
%a_lpc = lpc(s,p);


%% 4) Plot the prediction error and its magnitude spectrum



% figure(spectrum_fig);
% hold on;
% plot(faxes, db(abs(E)), 'DisplayName', 'E');
% legend();


%% 5) Build an impulse train with the estimated pitch period
% hint: initialize a vector of zeros and put a 1 every 1/pitch seconds


% normalize the energy: force the energy of the
% impulse train to be equal to that of the residual


%% 6) Consider the impulse train as excitation and build synthetic speech
%hint: if curious use fvtool() to visualize the filter you are using.
% Can you see the formants?


%% 7) Listen to the original and the synthetic speech


