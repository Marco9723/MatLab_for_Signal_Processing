%% MMSP2 - Lab 4
%  Exercise 1 - Transform coding

clear
close all
clc

%% 1) Load the first 4s of the file 'gb.wav' and quantize it with PCM and R=8 bit.
%%    Compute the MSE and perceptually evaluate the result.

% Load the file


% cut the first 4 seconds


% quantize with PCM and 8 bit

%compute MSE and SNR


% Listen the audio tracks 


%% 2) Consider groups of 8 symbols and quantize them using an optimal allocation of the 8 bits
% complete the function transform_coding
% hint: consider each block of 8 symbols as if composed by 8 transform
% coefficients


% Define the transformation matrix



%% 3) Consider DCT transformation and repeat step 2 over transformed 
%%    coefficients. Find the distortion and evaluate the perceived quality.


%% 4) Consider a Karhunen-Loeve transformation and repeat step 2 over transformed 
%%    coefficients. Find the distortion and evaluate the perceived quality.

% compute correlation
% hint: remove the average from the signal
% hint: compute many 8x8 correlation matrix, then average them

% remove signal mean


% Estimate the autocorrelation for groups of 8 symbols

% compute eigenvectors and eigenvalues of the autocorrelation matrix

% define the transformation matrix (be aware that we need a transformation
% matrix where the rows are our projection basis!)



%% 5) Plot the amount of bits allocated for each of the proposed solutions





















