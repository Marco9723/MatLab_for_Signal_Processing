%% MMSP2 - Lab 2
%  Exercise 2 - Uniform and optimal quantizer

clearvars

close all
clc

%% 1) Generate a 10000-sample realization of s_g(n)~N(0,2) and s_u(n)~U with variance 2 and mean 0
%%    hint: use the functions randn() and rand()


% Normal distribution

  
% Uniform distribution


%% 2) Quantize s_g(n) and s_u(n) with M=[4,8,16,32,64,128] levels and uniform
%%    quantizer. Plot R-D curve for each number of levels. Compare with the
%%    theoretical distortion for a uniform scalar quantizer considering a uniform
%%    distributed signal
%%    hint: use MSE as distortion metric and plot the SNR



% for each level
    
    % compute the quantization step

    
    % perform quantization


    
    % quantization error


    % MSE




% plot R-D curves



% Theoretical bound



% we could have computed directly snr_t = pow2db(2.^(2*R))




%% 3) Design an optimum uniform quantizer and a Lloyd-Max quantizer for s_g(n)
%%    with the same levels defined in the previous step. 
%%    Compare the R-D curves obtained with those quantizers
%%    with those obtained with uniform quantizer


% for each level
    
    % compute uniform thresholds
    
    
    % compute optimum reconstruction levels

    
    % quantization error
    
    
    % MSE
    
    % Lloyd-Max quantizer with Matlab implementation
    
    
    % quantization error
    
    % MSE
    

% compute SNR



% plot R-D curves
