%% MMSP2 - Lab 2
%  Exercise 4 - Vector quantization

clearvars
close all
clc

%% 1) Consider a 2D vector quantizer with codebook y1=(1,2), y2=(1,4), y3=(-1,2), y4=(0,-2)
%%    Show optimal assignement regions



%% 2) Quantize the sequence x=(-4:5) using groups of 2 consecutive 
% samples at time



% MATLAB way


%% 3) Plot the original and the quantized sequences

