%% MMSP2 - Lab 2
%  Exercise 3 - Scalar quantization

clearvars
close all
clc

%% 1) Suppose that you are sampling the output of a sensor at 10 kHz for 10 seconds.
%%    Quantize the output with a uniform quantizer at 10 bit per sample.
%%    Assume that the pdf of the signal is gaussian with mean 0 V and variance 4 V^2.
%%    What is the bit rate of the quantized signal?




%% 2) What would be a reasonable choice for the quantization step?



%% 3) What is the MSE?

% quantization error


% MSE

%% What is the resulting SNR?

