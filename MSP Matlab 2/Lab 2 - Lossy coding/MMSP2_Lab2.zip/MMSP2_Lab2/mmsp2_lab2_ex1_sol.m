%% MMSP2 - Lab 2
%  Exercise 1 - Basic scalar Quantization

clc
clearvars
close all

%% Generate 1000 samples with gaussian distribution


%% Quantize with a scalar mid-rise quantizer with fixed quantization step delta=2




%% Quantize with a scalar mid-tread quantizer with fixed quantization step delta=2



%% Quantize with a scalar mid-tread quantizer with M=4 output levels



%% Quantize using cb = [-5,-3,-1,0,1,3,5] as reproduction levels
% and th = [-4,-2,-0.5,0.5,2,4] as thresholds



%% Power and var


%% Compute distortion using MSE for each one of the above quantizers


%% Compute SNR for each one of the above quantizers


% if we want the snr to be in dB we can use one of the following:



